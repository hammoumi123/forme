﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace CodeReviewFunctions
{
    public class StringConverter
    {
        public string? StringOf(object o, Type type)

        {
            if (o == null)
            {
                return null;
            }
          if (type == typeof(bool) || Nullable.GetUnderlyingType(type) == typeof(bool))
        {
            return (bool)o ? "True" : "False";
        }

        if (type == typeof(DateTime) || Nullable.GetUnderlyingType(type) == typeof(DateTime))
        {
            var dateTime = ((DateTime)o);

            if (dateTime.TimeOfDay > TimeSpan.FromSeconds(0))
            {
                if (dateTime.Year <= 1900)
                {
                    return dateTime.ToString("hh:mm:ss tt");
                }

                return dateTime.ToString("dd/MM/yyyy hh:mm:ss tt");
            }

            return dateTime.ToString("dd/MM/yyyy");
        }

        if (type.IsEnum)
        {
            if (o is Enum e && Enum.IsDefined(type, e))
            {
                var eName = Name(e) ?? Enum.GetName(type, e);
                return eName;
            }
        }

        return o.ToString();
    }

    public string? Name(Enum e)
    {
        if (e == null)
        {
            throw new ArgumentNullException(nameof(e));
        }

        if (!Enum.IsDefined(e.GetType(), e))
        {
            return string.Empty;
        }

        FieldInfo? info = e.GetType().GetField(e.ToString());
        DisplayAttribute? attr = info?.GetCustomAttributes(typeof(DisplayAttribute), false).FirstOrDefault() as DisplayAttribute;

        return attr == null ? e.ToString() : attr.Name;
    }
  }
}


    
