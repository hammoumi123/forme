﻿using System.Text;
using System.Xml;

namespace CodeReviewFunctions
{
    public class DifferenceFinder
    {
        private List<string> DifferenceExclusions { get; }

        public DifferenceFinder(List<string> differenceExclusions)
        {
            DifferenceExclusions = differenceExclusions;
        }

        public string Differences(string BeforeValues, string AfterValues)
        {
            bool bothFinished;
            bool aFinished = false;
            bool bFinished = false;

            XmlNode aNode = null;
            XmlNode bNode = null;

            XmlDocument bXML = new XmlDocument();
            if (!string.IsNullOrEmpty(BeforeValues))
            {
                bXML.LoadXml(BeforeValues);
                bNode = bXML.ChildNodes[0];
            }
            else
            {
                bFinished = true;
            }

            XmlDocument aXML = new XmlDocument();
            if (!string.IsNullOrEmpty(AfterValues))
            {
                if (AfterValues == "DELETED")
                {
                    return "Deleted";
                }
                aXML.LoadXml(AfterValues);
                aNode = aXML.ChildNodes[0];
            }
            else
            {
                aFinished = true;
            }

            if (bFinished)
            {
                return "New entry";
            }

            XmlNodeList aChildren = aNode.ChildNodes;
            XmlNodeList bChildren = bNode.ChildNodes;

            int aCount = 0;
            int bCount = 0;
            int aTotal = aChildren.Count;
            int bTotal = bChildren.Count;

            StringBuilder differences = new StringBuilder();

            do
            {

                XmlNode aChild = null;
                if (!aFinished)
                    aChild = aChildren[aCount];

                XmlNode bChild = null;
                if (!bFinished)
                    bChild = bChildren[bCount];

                if (aChild != null && bChild != null)
                {
                    if (aChild.Name == bChild.Name)
                    {
                        if (aChild.InnerText != bChild.InnerText && !DifferenceExclusions.Contains(aChild.Name))
                        {
                            differences.Append(bChild.Name + " changed from '" + bChild.InnerText + "' to '" + aChild.InnerText + "'" + Environment.NewLine);
                        }
                        aCount++;
                        bCount++;
                    }
                    else
                    {
                        if (!DifferenceExclusions.Contains(aChild.Name))
                        {
                            differences.Append(aChild.Name + " set to '" + aChild.InnerText + "'" + Environment.NewLine);
                        }
                        aCount++;
                    }
                }
                else if (bChild == null)
                {
                    if (!DifferenceExclusions.Contains(aChild.Name))
                    {
                        differences.Append(aChild.Name + "set to '" + aChild.InnerText + "'" + Environment.NewLine);
                    }
                    aCount++;
                }
                else
                {
                    bCount++;
                }

                aFinished = aCount >= aTotal;
                bFinished = bCount >= bTotal;
                bothFinished = aFinished && bFinished;

            } while (!bothFinished);

            return differences.ToString();
        }
    }
}

